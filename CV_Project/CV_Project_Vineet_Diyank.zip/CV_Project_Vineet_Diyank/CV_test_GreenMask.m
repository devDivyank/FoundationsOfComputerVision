function features=CV_test_GreenMask(input)
image = imread(input);
image = image(:,:,1:3);


% Extracts the color channels
redChannel = image(:, :, 1);
greenChannel = image(:, :, 2);
blueChannel = image(:, :, 3);

% Defines color channel thresholds for green
redThres = 100;
greenThres = 80;
blueThres = 100;

% Creates a binary green mask
greenMask = (redChannel < redThres) & ...
             (greenChannel > greenThres) & ...
             (blueChannel < blueThres);

% Defines the structuring element for dilation
se = strel('disk', 3); % You can adjust the size of the disk as needed

% Dilates the green mask
dilatedGreenMask = imdilate(greenMask, se);

% Fills holes in the green mask
filledGreenMask = imfill(dilatedGreenMask, 'holes');

% Applies the filled green mask to the original image
maskedImage = image;
maskedImage(repmat(~filledGreenMask, [1, 1, 3])) = 0;

% Creates a binary white mask
redThresWhite = 160;
greenThresWhite = 160;
blueThresWhite = 160;

whiteMask = (redChannel > redThresWhite) & ...
            (greenChannel > greenThresWhite) & ...
            (blueChannel > blueThresWhite);

% Combines the white mask and the green mask to get white dots on the green patch
whiteObjectsOnGreenPatch = filledGreenMask & whiteMask;

% Removes small white objects opening
seOpening = strel('disk', 1);
whiteObjectsOnGreenPatchOpened = imopen(whiteObjectsOnGreenPatch, seOpening);

% Labels connected components (white cotton buds)
[labeledWhiteObjects, numWhiteCottonBuds] = bwlabel(whiteObjectsOnGreenPatchOpened);

% Calculates the area of the green patch
greenArea = sum(filledGreenMask, 'all');

% Calculates the mean green intensity in the green patch
greenIntensityInPatch = greenChannel(filledGreenMask);
meanGreenIntensity = mean(greenIntensityInPatch, 'all');

% % % Display the green area
% fprintf('The area of the green patch is %d pixels.\n', greenArea);
% % 
% % % Display the white
% fprintf('The number of white dots is %d.\n', numWhiteCottonBuds);
% 
% % % Display the green intensity
% fprintf('The mean intensity of the green color in the green patch is %.2f.\n', meanGreenIntensity);

features = zeros(1, 3);
features(1,1)=greenArea;
features(1,2)=numWhiteCottonBuds;
features(1,3)=meanGreenIntensity;

end