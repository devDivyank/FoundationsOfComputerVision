function CV_Project_Main()
    % For WINDOWS, use these:
    % imageDir='cotton images and labels\cotton images\';
    % labelDir='cotton images and labels\labels\labels_rgb.csv';
    
%     For MAC/LINUX, use these:
    imageDir='cotton images and labels/cotton images/';
    labelDir='cotton images and labels/labels/labels_rgb.csv';
    
    imgClassesCSV = readtable(labelDir);
    %imgIds = imgClassesCSV.image_ID;
    labels = categorical(imgClassesCSV.class);
    
    % How many images to process
    iter=2240;
    
    % Gets name of image to be processed
    imagePrefix="20220818_lb_p4r_twri_mosaic%d.tif";
    
    
    X = [];
    Y = [];
    
    
        for i = 1 : iter   
            % Loads current image
            file_number = 559 + i;
            file_name = sprintf(imagePrefix, file_number);
    
            %features from green mask
            current_features=CV_test_GreenMask(imageDir+file_name);
    
            % Appends current features to feature matrix X
            X = [X; current_features];
            
            % Appends current label to label vector Y
            Y = [Y; labels(i)];
    
            %Prints progress
            fprintf('Image Processed %d\n', file_number);
    
        end
    
    fprintf('---------Training Decision Tree Classifier-----------\n');
     
    % decision tree 
    
    % Split data into training and testing sets
    cv = cvpartition(size(Y,1),'HoldOut',0.25);
    X_train = X(training(cv),:);
    Y_train = Y(training(cv));
    X_test = X(test(cv),:);
    Y_test = Y(test(cv));
    
    % Train decision tree classifier
    tree = fitctree(X_train,Y_train);
    
    % Predict on test set and calculate accuracy
    Ypred = predict(tree,X_test);
    accuracy = sum(Ypred == Y_test)/numel(Y_test);
    
    %Print accuracy
    fprintf('The accuracy found is %.2f%% \n', (accuracy*100));

end